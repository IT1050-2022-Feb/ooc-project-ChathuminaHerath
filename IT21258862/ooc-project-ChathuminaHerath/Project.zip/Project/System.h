#define SIZE 10
#include <string>>
#include"Admin.h";

class System{

private:

Admin* Admin[SIZE];


string Products;
string Orders;
double Price;


public:

System();
System(string pProducts, string pOrders,double pPrice);
void CalculateTotal();
void ViewSystemStatus();
void DisplayOrderDetails();
~System();
};