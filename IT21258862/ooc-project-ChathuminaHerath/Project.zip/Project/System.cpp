
#include<iostream>
using namespace std;
#include <string>
#include"System.h"



System::System()
  {
cout << "Default Constructor System() called" << endl;
}


System::System(string pProducts, string pOrders,double pPrice)
{
Products=pProducts;
Orders=pOrders;
Price=pPrice;

}


System::~System()
{
 cout << "Destructed" << endl;
}

